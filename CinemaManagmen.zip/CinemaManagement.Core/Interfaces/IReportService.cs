﻿namespace CinemaManagement.Core.Interfaces;

public partial interface IReportService
{
    
}