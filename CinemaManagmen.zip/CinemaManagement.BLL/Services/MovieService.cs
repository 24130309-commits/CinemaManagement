﻿namespace CinemaManagement.BLL.Services;

public class MovieService
{
    
}